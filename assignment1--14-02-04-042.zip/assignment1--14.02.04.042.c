#include<stdio.h>

  void delComments()
  {
    FILE *f1, *f2;
    char ch, nextc;
    f1 = fopen ("input.txt", "r");
    f2 = fopen ("output1.txt", "w");
    if (f1 == NULL)
       printf ("Opening error");
    if (f2 == NULL)
       printf ("Opening error");
    nextc = fgetc (f1);
    while (nextc != EOF)
  {
     ch = nextc;
     nextc = fgetc (f1);

     if ((ch == '/') && (nextc == '*'))
     {
        ch = fgetc (f1);
        nextc = fgetc (f1);
        while (!((ch == '*') && (nextc == '/')))
        {
          ch = nextc;
          nextc = fgetc (f1);
        }
     nextc = fgetc (f1);
     continue;

     }
     else if((ch=='/') && (nextc == '/'))
     {
        nextc = fgetc (f1);
        while (!(nextc == '\n')){
           nextc = fgetc (f1);
        }
       nextc = fgetc (f1);
       continue;
     }
     putc (ch, f2);
   }
    fclose (f1);
    fclose (f2);
    f1 = fopen("input.txt","r");
    f2 = fopen("output1.txt","r");
    printf("Input File......:\n\n ");

    while((ch=fgetc(f1))!=EOF)
        printf("%c",ch);
    printf("\n");
    printf("Output File After Deleting Comment....:\n\n ");
    while((ch=fgetc(f2))!=EOF)
        printf("%c",ch);
    printf("\n\n");
    fclose(f2);
}


void delSpaces(){

    FILE *f1,*f2;
    char ch;
    f1=fopen("output1.txt","r");
    f2=fopen("output2.txt","w");
    if (f1 == NULL)
       printf ("Opening error");
    if (f2 == NULL)
       printf ("Opening error");

    while((ch=getc(f1))!=EOF){
        if(ch==' '){
        putc(ch,f2);
            while((ch=getc(f1))==' '){}
            putc(ch,f2);
       }
    else
        putc(ch,f2);
   }

    fclose(f1);
    fclose(f2);
    f1 = fopen("output1.txt","r");
    f2 = fopen("output2.txt","r");
    printf("Output File After Deleting Spaces:\n\n ");
    while((ch=fgetc(f2))!=EOF)
        printf("%c",ch);
    printf("\n\n");
    fclose(f2);

}

void delNewLine()
{

    FILE *f1,*f2;
    char ch;
    f1=fopen("output2.txt","r");
    f2=fopen("output_final.txt","w");
    if (f1 == NULL)
       printf ("Opening error");
    if (f2 == NULL)
       printf ("Opening error");

    while((ch=getc(f1))!=EOF){
        if(ch=='\n')
        {
        putc(' ',f2);
        while( ((ch=getc(f1))=='\n') || (ch==' ') ){
        }
      if(ch!=EOF)
        putc(ch,f2);
        }
      else
        putc(ch,f2);
    }
    fclose(f1);
    fclose(f2);
    f1 = fopen("input.txt","r");
    f2 = fopen("output_final.txt","r");
    printf("Final Output File After Deleting New Line...:\n\n");
    while((ch=fgetc(f2))!=EOF)
        printf("%c",ch);
        fclose(f2);
}
int main()
{
    delComments();
    delSpaces();
    delNewLine();

    return 0;
}
