#include<stdio.h>

struct symbol_tbl
{
    int S_id;
    char name[10];
    char type[10];
    char dt_type[10];
    char scope[10];

}S_table[20];

int N;
char Scope[]="global";
FILE* f1, *f2;

int Keyword(char s[])
{
    int i;
    char key[][10] = { "char","int","double","float","void" };
    for(i=0; i<5; i++)
    {
        if(strcmp(s,key[i])==0)
        {
            return 1;
            break;
        }
    }
    return 0;
}

int Id_chk(char name[], char scope[])
{
    int i;
    for(i=1; i<N; i++)
    {
        if( (strcmp(scope, S_table[i].scope)==0) && (strcmp(name, S_table[i].name)==0))
          {
            return S_table[i].S_id ;
            }
       }

      for(i=1; i<N; i++){
        if(strcmp(name, S_table[i].name)==0)
           return S_table[i].S_id;
    }

}

 void step1()
 {
    int i,ck;
    f1 = fopen("input.txt", "r");
    f2 = fopen("output1.txt", "w");

    char k[][10] = {"[kw", "[op", "[num","[brc", "[sep" ,"[par" };
    char s[10];

    while(fscanf(f1,"%s", &s)!=EOF)
    {
        for(i=0;i<6;i++)
        {
            if(strcmp(s,k[i])==0)
            {
                ck = 1;
            break;
            }
            else ck = 0;
        }
     if(ck==1)fputc('[',f2);
    else fprintf(f2, "%s", s);
     if(strcmp("[id",s)==0) fputc(' ',f2);
    }
    fclose(f1);
    fclose(f2);

    printf("Step 1:...\n");
    char c;
    f1 = fopen("output1.txt", "r");
    while((c=fgetc(f1))!=EOF)
    {
        printf("%c", c);
    }
    fclose(f1);
    printf("\n\n");
 }


 void step2(){

    f1 = fopen ("output1.txt", "r");
    f2 = fopen ("output2.txt", "w");
    char s[20];
    char ch;
    while((ch=fgetc(f1))!=EOF){

        if((ch== '[')  || (ch==']')){fputc(' ',f2);}
        else fputc(ch,f2);
    }
    fclose(f1);
    fclose(f2);

    f1 = fopen("output2.txt", "r");
    N=1;
     while(fscanf(f1,"%s", &s)!=EOF){

        if(Keyword(s)==1){
             strcpy(S_table[N].dt_type, s);
             fscanf(f1,"%s", &s);
             if(strcmp(s,"id")==0){
                fscanf(f1,"%s", &s);
                strcpy(S_table[N].name, s);

                fscanf(f1,"%s", &s);
                if(strcmp(s,"(")==0){
                    strcpy(S_table[N].type, "func");
                 strcpy(S_table[N].scope, Scope);
                 strcpy(Scope, S_table[N].name);
                }
                else{
                strcpy(S_table[N].type, "var");
                 strcpy(S_table[N].scope, Scope);
                }
                 S_table[N].S_id = N;
                 N++;
             }
        }
              else if(strcmp("}", s)==0)
                    strcpy(Scope, "global");


     }

       printf("Step 2:...\n\n");
        int i;
         for(i=1; i<N; i++)
    {
        printf("  %d\t%s\t%s\t%s\t%s\n", S_table[i].S_id, S_table[i].name, S_table[i].type, S_table[i].dt_type, S_table[i].scope);
    }

    printf("\n");
 }

 void step3()
 {
    f1 = fopen("output2.txt", "r");
     f2 = fopen("output3.txt", "w");
    char ch,s[20],s1[20];


    while(fscanf(f1,"%s",s)!=EOF){
        fputc('[',f2);
        fprintf(f2, "%s" ,s);
        if(strcmp("(",s)==0){
           strcpy(Scope,s1);
        }
        if(strcmp("}",s)==0){
            strcpy(Scope, "global");}

        if(strcmp(s,"id")==0){
            fputc(' ',f2);
            fscanf(f1,"%s",s);
            fprintf(f2, "%d", Id_chk(s, Scope));
            strcpy(s1,s);
        }
        fputc(']',f2);
    }
    fclose(f1);
    fclose(f2);

    printf("Step 3:...\n\n");

    f1 = fopen("output3.txt", "r");
    while((ch=fgetc(f1))!=EOF)
    {
        printf("%c", ch);
    }
    fclose(f1);
    printf("\n");
 }

int main()
{
     step1();
     step2();
     step3();

    return 0;

}
